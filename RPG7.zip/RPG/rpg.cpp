#include <windows.h>
#include <gdiplus.h>
using namespace Gdiplus;// GDI+

#pragma comment(lib, "gdiplus.lib") // GDI+

//-------------------------------------------
// �萔
//-------------------------------------------
const int TILE      = 32;
const int PLAYER_W  = 32;
const int PLAYER_H  = 32;

int screenW   = 640;
int screenH   = 480;

//-------------------------------------------
// �ϐ�
//-------------------------------------------
// �A�j���[�V�����i�펞���[�v�j
int animLoop[4] = { 0,1,2,1 }; // 0��1��2��1��0��1��2��1��0�R�}�ڂ̕\���̃��[�v�ŃA�j���[�V����
int animIndex = 0;
int animTimer = 0;

// �v���C���[�̌����i0=�O,1=��,2=�E,3=��j
int playerDir = 3;

// �w�i�X�N���[���ʒu
int mapOffsetX = 0;
int mapOffsetY = 0;

// �v���C���[����ʒ��S�ɌŒ�
int playerScreenX;
int playerScreenY;

// �摜
Image* imgPlayer = nullptr;
Image* imgGround = nullptr;

// �_�u���o�b�t�@
HBITMAP backBuffer = nullptr;
HDC backDC = nullptr;

// �L�[���
bool keyUp = false, keyDown = false, keyLeft = false, keyRight = false;

// GDI+
ULONG_PTR gdiToken;

//-------------------------------------------
// �^�C���ړ��p
//-------------------------------------------
bool    isMoving    = false;
int     moveDx      = 0;
int     moveDy      = 0;
int     moveRemain  = 0;

//-------------------------------------------
// ���͏���
//-------------------------------------------
void UpdateInput(){

    keyUp       = (GetAsyncKeyState(VK_UP)      & 0x8000);
    keyDown     = (GetAsyncKeyState(VK_DOWN)    & 0x8000);
    keyLeft     = (GetAsyncKeyState(VK_LEFT)    & 0x8000);
    keyRight    = (GetAsyncKeyState(VK_RIGHT)   & 0x8000);
}

//-------------------------------------------
// �^�C���ړ�����
//-------------------------------------------
void UpdateMove(){

    int moveSpeed = 8; // 8px �Âړ�

    if (isMoving) {                         // �ړ����ׂ��������܂��c���Ă���
        mapOffsetX += moveDx * moveSpeed;   // �ړ����ׂ����W�����߂�
        mapOffsetY += moveDy * moveSpeed;
        moveRemain -= moveSpeed;            // �ړ����ׂ��������X�V

        if (moveRemain <= 0) {              // �ړ����ׂ��������Ȃ��Ȃ��
            isMoving = false;               // �ړ��s�v�Ƃ���
 
        }
        return;
    }

    if (keyUp) {                // ����L�[�������ꂽ
        moveDx      = 0;        // �ړ��� 
        moveDy      = -1;       //  
        playerDir   = 3;        // �ړ�����
        isMoving    = true;     // �ړ����t���O
        moveRemain  = TILE;     // �ړ������i�ő�P�^�C�����j
    }
    else if (keyDown) {
        moveDx      = 0;
        moveDy      = +1;
        playerDir   = 0;
        isMoving    = true;
        moveRemain  = TILE;
    }
    else if (keyLeft) {
        moveDx      = -1;
        moveDy      = 0;
        playerDir   = 1;
        isMoving    = true;
        moveRemain  = TILE;
    }
    else if (keyRight) {
        moveDx      = +1;
        moveDy      = 0;
        playerDir   = 2;
        isMoving    = true;
        moveRemain  = TILE;
    }
}

//-------------------------------------------
// �A�j���[�V����
//-------------------------------------------
void UpdateAnimation(){

    animTimer++;
    if (animTimer >= 4) {
        animTimer = 0;
        animIndex = (animIndex + 1) % 4;
    }
}

//-------------------------------------------
// �`��
//-------------------------------------------
void DrawGame(HWND hWnd){

    HDC hdc = GetDC(hWnd);

    Graphics g(backDC);
    g.Clear(Color(0, 0, 0));

    //-----------------------------------
    // �w�i�^�C���`��
    //-----------------------------------
    int startX = -((mapOffsetX % TILE + TILE) % TILE);
    int startY = -((mapOffsetY % TILE + TILE) % TILE);

    for (int y = 0; y <= screenH / TILE + 1; y++) {
        for (int x = 0; x <= screenW / TILE + 1; x++) {
            int drawX = startX + x * TILE;
            int drawY = startY + y * TILE;
            g.DrawImage(imgGround, drawX, drawY, TILE, TILE);
        }
    }

    //-----------------------------------
    // �v���C���[�i���S�Œ�j�`��
    //-----------------------------------
    int sx = animLoop[animIndex] * PLAYER_W;
    int sy = playerDir * PLAYER_H;

    g.DrawImage(
        imgPlayer,
        playerScreenX, playerScreenY,
        sx, sy, PLAYER_W, PLAYER_H,
        UnitPixel
    );

    BitBlt(hdc, 0, 0, screenW, screenH, backDC, 0, 0, SRCCOPY);
    ReleaseDC(hWnd, hdc);
}

//-------------------------------------------
// WndProc
//-------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM w, LPARAM l){

    switch (msg) {
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;

    case WM_PAINT:
        PAINTSTRUCT ps;
        BeginPaint(hWnd, &ps);
        DrawGame(hWnd);
        EndPaint(hWnd, &ps);
        return 0;
    }
    return DefWindowProc(hWnd, msg, w, l);
}

//-------------------------------------------
// WinMain
//-------------------------------------------
int APIENTRY wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int)
{
    screenW = TILE * 15;
    screenH = TILE * 9;

    RECT rc = { 0, 0, screenW, screenH };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);


    // GDI+ ������
    GdiplusStartupInput gdiSI;
    GdiplusStartup(&gdiToken, &gdiSI, NULL);

    // �E�B���h�E
    WNDCLASS wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"MyRPG";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClass(&wc);

    HWND hWnd = CreateWindow(
        L"MyRPG", L"RPG",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        rc.right - rc.left, 
        rc.bottom - rc.top,
        NULL, NULL, hInst, NULL
    );
    ShowWindow(hWnd, SW_SHOW);

    // �o�b�t�@�쐬
    HDC hdc = GetDC(hWnd);
    backDC = CreateCompatibleDC(hdc);
    backBuffer = CreateCompatibleBitmap(hdc, screenW, screenH);
    SelectObject(backDC, backBuffer);
    ReleaseDC(hWnd, hdc);

    // �v���C���[�ʒu�i��ʒ����j
    playerScreenX = screenW / 2 - PLAYER_W / 2;
    playerScreenY = screenH / 2 - PLAYER_H / 2;

    // �摜�ǂݍ���
    imgPlayer = new Image(L"res/player.png");
    imgGround = new Image(L"res/ground.png");

    //---------------------------------------
    // �t���[�����[�g����i60FPS�j
    //---------------------------------------
    LARGE_INTEGER freq, prev, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&prev);

    const double frameTime = 1.0 / 60.0;

    MSG msg = {};
    while (msg.message != WM_QUIT) {

        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else {

            QueryPerformanceCounter(&now);
            double dt = (double)(now.QuadPart - prev.QuadPart) / freq.QuadPart;

            if (dt >= frameTime) {
                prev = now;

                UpdateInput();
                UpdateMove();
                UpdateAnimation();

                InvalidateRect(hWnd, NULL, FALSE);
            }
            else {
                Sleep(0);
            }
        }
    }

    delete imgPlayer;
    delete imgGround;
    GdiplusShutdown(gdiToken);

    return 0;
}
