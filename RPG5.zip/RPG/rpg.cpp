#include <windows.h>
#include <gdiplus.h>
using namespace Gdiplus;

#pragma comment(lib, "gdiplus.lib")

ULONG_PTR g_gdiplusToken;

// �v���C���[
Image* g_sprite = nullptr;

// �^�C���摜
Image* g_tile = nullptr;

// �L�����̃s�N�Z����
const int FRAME_W = 32;
const int FRAME_H = 32;

// �w�i�̃s�N�Z����
const int TILE_W = 32;
const int TILE_H = 32;

// �v���C���[�̍��W
int playerX = 100;
int playerY = 100;

// ���L�[�̏��
bool keyUp = false, keyDown = false, keyLeft = false, keyRight = false;


Bitmap* backBuffer = nullptr;
Graphics* backGraphics = nullptr;

// ---- �A�j���[�V���� ----
int animLoop[8] = { 0,1,2,1,0,1,2,1 };
int animIndex = 0;
int direction = 0;


// =====================================================
// �o�b�N�o�b�t�@�쐬
// =====================================================
void CreateBackBuffer(HWND hwnd) {
    RECT rc;
    GetClientRect(hwnd, &rc);

    delete backBuffer;
    delete backGraphics;

    backBuffer = new Bitmap(rc.right, rc.bottom, PixelFormat32bppARGB);
    backGraphics = new Graphics(backBuffer);
}

// =====================================================
// �A�j���X�V
// =====================================================
void UpdateAnimation() {
    animIndex = (animIndex + 1) % 8;
}

// =====================================================
// �ړ�
// =====================================================
void UpdatePlayer() {
    if (keyUp)      { playerY -= 8; direction = 3; }
    if (keyDown)    { playerY += 8; direction = 0; }
    if (keyLeft)    { playerX -= 8; direction = 1; }
    if (keyRight)   { playerX += 8; direction = 2; }
}

// =====================================================
// �`��
// =====================================================
void DrawScene(HWND hWnd, HDC hdc) {

    if (!backBuffer) return;

    RECT rc;
    GetClientRect(hWnd, &rc);
    int width   = rc.right;
    int height  = rc.bottom;

    // �o�b�t�@�𖈃t���[���N���A�i�c���h�~�j
    backGraphics->Clear(Color(255, 0, 0, 0));

    // �w�i�^�C����~��
    for (int y = 0; y < height; y += TILE_H) {
        for (int x = 0; x < width; x += TILE_W) {
            backGraphics->DrawImage(g_tile, x, y, TILE_W, TILE_H);
        }
    }

    // �A�j���t���[��
    int frame = animLoop[animIndex];
    int sx = frame * FRAME_W;
    int sy = direction * FRAME_H;

    // �v���C���[�`��
    backGraphics->DrawImage(
        g_sprite,
        Rect(playerX, playerY, FRAME_W, FRAME_H),
        sx, sy, FRAME_W, FRAME_H,
        UnitPixel
    );

    // �o�b�t�@ �� �\��
    Graphics g(hdc);
    g.DrawImage(backBuffer, 0, 0);
}

// =====================================================
// WndProc
// =====================================================
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {

    switch (msg) {

    case WM_SIZE:
        CreateBackBuffer(hWnd);
        //  �L������kyo�����ɔz�u
        playerX = (LOWORD(lParam) - FRAME_W) / 2;
        playerY = (HIWORD(lParam) - FRAME_H) / 2;
        break;

    case WM_KEYDOWN:
        if (wParam == VK_UP)        keyUp       = true;
        if (wParam == VK_DOWN)      keyDown     = true;
        if (wParam == VK_LEFT)      keyLeft     = true;
        if (wParam == VK_RIGHT)     keyRight    = true;
        if (wParam == VK_ESCAPE)    PostQuitMessage(0);
        break;

    case WM_KEYUP:
        if (wParam == VK_UP) {
            keyUp = false;
            // �ぁ�؂�̂� ������  �i32px�P�ʂɃX�i�b�v���ł�������Ƃ������[�v����̂��s���R�j
            playerY = (playerY / TILE_H) * TILE_H;
        }
        if (wParam == VK_DOWN) {
            keyDown = false;
            // �����؂�グ ������
            playerY = ((playerY + TILE_H - 1) / TILE_H) * TILE_H;
        }
        if (wParam == VK_LEFT) {
            keyLeft = false;
            // �����؂�̂� ������
            playerX = (playerX / TILE_W) * TILE_W;
        }
        if (wParam == VK_RIGHT) {
            keyRight = false;
            // �E���؂�グ ������
            playerX = ((playerX + TILE_W - 1) / TILE_W) * TILE_W;
        }
        break;

    case WM_TIMER:
        UpdatePlayer();
        UpdateAnimation();
        InvalidateRect(hWnd, NULL, FALSE);
        break;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        DrawScene(hWnd, hdc);   
        EndPaint(hWnd, &ps);
    }
        break;

    case WM_DESTROY:
        delete backBuffer;
        delete backGraphics;

        delete g_sprite;
        delete g_tile;

        GdiplusShutdown(g_gdiplusToken);
        PostQuitMessage(0);

        break;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

// =====================================================
// WinMain
// =====================================================
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {

    RECT rc = { 0, 0, TILE_W * 13, TILE_H * 9 };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);

    GdiplusStartupInput gsi;
    GdiplusStartup(&g_gdiplusToken, &gsi, nullptr);

    // �v���C���[�摜
    g_sprite = new Image(L"./res/player.png");

    // �� �^�C���摜
    g_tile = new Image(L"./res/ground.png");

    // �E�B���h�E�N���X
    WNDCLASS wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"MyRPG";
    RegisterClass(&wc);

    // �E�B���h�E�쐬
    HWND hWnd = CreateWindow(
        L"MyRPG", L"RPG",
        WS_OVERLAPPEDWINDOW,
        200, 200,
        rc.right - rc.left,
        rc.bottom - rc.top,
        NULL, NULL, hInst, NULL
    );

    ShowWindow(hWnd, nCmdShow);

    // �^�C�}�[�i100ms�j
    SetTimer(hWnd, 1, 100, NULL);


    CreateBackBuffer(hWnd);    //  �ŏ��Ƀo�b�N�o�b�t�@�쐬�iWM_SIZE �����Ȃ��ꍇ������j


    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
